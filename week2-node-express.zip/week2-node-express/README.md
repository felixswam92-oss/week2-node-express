# Week 2 Node.js and Express API

A simple Express application built for the BeTechified "Build & Deploy Your API" assignment.

## Features

- `GET /` serves a static HTML home page containing **My Week 2 API!**
- `POST /user` accepts `name` and `email`, validates both fields, and responds with a greeting.
- `GET /user/:id` returns a simple user profile message.
- JSON request-body parsing with `express.json()`.
- HTTP 400 responses for missing or invalid request data.
- Configurable port using a `.env` file.
- Bonus custom middleware that logs each request.

## Requirements

- Node.js and npm

## Setup

1. Open this project folder in a terminal.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to a new file named `.env`. Keep the default value:

   ```env
   PORT=3000
   ```

4. Start the server:

   ```bash
   npm start
   ```

5. Open `http://localhost:3000` in your browser.

For development with automatic restart, run `npm run dev`.

## Test the API

### 1. Home page

Open `http://localhost:3000` in a browser, or run:

```bash
curl http://localhost:3000
```

### 2. Create/greet a user

```bash
curl -X POST http://localhost:3000/user \
  -H "Content-Type: application/json" \
  -d '{"name":"Felix","email":"felix@example.com"}'
```

Expected JSON response:

```json
{
  "message": "Hello, Felix!",
  "name": "Felix",
  "email": "felix@example.com"
}
```

### 3. Test missing data (HTTP 400)

```bash
curl -X POST http://localhost:3000/user \
  -H "Content-Type: application/json" \
  -d '{"name":"Felix"}'
```

Expected status: `400 Bad Request`.

### 4. Get a user profile

```bash
curl http://localhost:3000/user/123
```

Expected JSON response:

```json
{
  "message": "User 123 profile",
  "id": "123"
}
```

## Test with Postman

- For the home page, create a `GET` request to `http://localhost:3000/`.
- For the greeting, create a `POST` request to `http://localhost:3000/user`, choose **Body → raw → JSON**, and enter:

  ```json
  {
    "name": "Felix",
    "email": "felix@example.com"
  }
  ```

- For a profile, create a `GET` request to `http://localhost:3000/user/123`.
- To verify validation, send the POST request with either `name` or `email` missing. The server should return status `400`.

## Upload to GitHub

Create a new public repository named `week2-node-express` on GitHub. Do not initialize it with a README if you plan to push this existing project.

From inside this project folder, run:

```bash
git init
git add .
git commit -m "Build Week 2 Express API"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/week2-node-express.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Do not upload `.env` or `node_modules`.

After pushing, copy the repository URL and submit it as your assignment link.
