require("dotenv").config();

const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Parse incoming JSON request bodies.
app.use(express.json());

// Bonus: custom middleware that logs every incoming request.
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} ${req.method} ${req.url}`);
  next();
});

// Serve the static website from the public folder.
app.use(express.static(path.join(__dirname, "public")));

// GET / - the home page is a static HTML page.
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// POST /user - accept a name and email, then greet the user.
app.post("/user", (req, res) => {
  const { name, email } = req.body || {};

  if (
    typeof name !== "string" || !name.trim() ||
    typeof email !== "string" || !email.trim()
  ) {
    return res.status(400).json({
      error: "Missing data. Please provide both name and email."
    });
  }

  return res.status(200).json({
    message: `Hello, ${name.trim()}!`,
    name: name.trim(),
    email: email.trim()
  });
});

// GET /user/:id - return a simple user profile message.
app.get("/user/:id", (req, res) => {
  res.json({
    message: `User ${req.params.id} profile`,
    id: req.params.id
  });
});

// Handle malformed JSON and other errors.
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && "body" in err) {
    return res.status(400).json({ error: "Invalid JSON in request body." });
  }

  console.error(err);
  return res.status(500).json({ error: "Internal server error." });
});

app.listen(PORT, () => {
  console.log(`Week 2 API is running at http://localhost:${PORT}`);
});
